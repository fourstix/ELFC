/* fcntl definitions in stdlib */

#ifndef _STDLIB_
#include <stdlib.h>
#endif
