;------------------------------------------------------
; ElfC Asm/02 Opcodes
;------------------------------------------------------

.op "PUSH","N","9$1 73 8$1 73"
.op "POP","N","60 72 A$1 F0 B$1"
.op "CALL","W","D4 H1 L1"
.op "RTN","","D5"
.op "CLC","","FC 00"
.op "STC","","FF 00"
.op "COPY","NR","8$1 A$2 9$1 B$2"
.op "LOAD","NW","F8 L2 A$1 F8 H2 B$1"
.op "MATCH","NW","8$1 FF L2 52 9$1 7F H2 F1"
.op "BRKPT","","79 D1"
.op "ADDR16","NR","8$2 52 8$1 F4 A$1 9$2 52 9$1 74 B$1"
.op "SUBR16","NR","8$2 52 8$1 F7 A$1 9$2 52 9$1 77 B$1"
.op "GOSUB","W","D9 L1"
; RSUB returns through the first byte of the subroutine table, so it
; holds the page the C runtime module puts that table on: $2100 for
; Elf/OS, or $0E00 for ELF-DOS, which is the page after PROG_BASE.
#ifdef _EDOS_
.op "RSUB","","C0 0E 00"
#else
.op "RSUB","","C0 21 00"
#endif
.op "SHL16","N","8$1 FE A$1 9$1 7E B$1"
.op "SHLC16","N","8$1 7E A$1 9$1 7E B$1"
.op "SHR16","N","9$1 F6 B$1 8$1 76 A$1"
.op "SHRC16","N","9$1 76 B$1 8$1 76 A$1"



;------------------- end ops_c.inc --------------------
