/* All types are defined in stdlib */
#ifndef _STDLIB_
#include <stdlib.h>
#endif
